package com.example.database.databasejdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabaseJdbcApplication.class, args);
	}

}
