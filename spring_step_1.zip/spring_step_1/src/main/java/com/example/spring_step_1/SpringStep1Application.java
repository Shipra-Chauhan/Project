package com.example.spring_step_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringStep1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringStep1Application.class, args);
	}

}
